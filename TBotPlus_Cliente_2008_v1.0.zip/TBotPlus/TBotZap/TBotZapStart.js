const { default: makeWASocket, useMultiFileAuthState, MessageRetryMap, Presence, DisconnectReason, delay}  = require('@adiwajshing/baileys')

const { TBotZapNLP  } = require("./TBotZapFunction/TBotZapNLP")
const { TBotZapFreeAccount } = require('./TBotZapFunction/TBotZapFreeAccount')
const {TBotZapLoginTest} = require('./TBotZapClass/TBotZapCreateTest')
const { QRcode} = require('./TBotZapClass/TBotZapQrcode')
const { TBotZapSendLogin } = require('./TBotZapClass/TBotZapSendLogin')
const { TBotZapDBStatus } = require('./TBotZapFunction/TBotZapDatabaseStatus')
const {TBotZapSendAccountSSH} = require('./TBotZapClass/TBotZapSendAccountSSH')
const {TWABotFirstLoginTime, TWABotFileExist, TWABotLinkMediafire, TWABotLinkPlayStore, TWABotLoginLimit, TWABotLinkSupport, TWABotFirsLoginPrice, TWABotOpenFile} = require('./Util/TBotZapData')
const fs = require('fs')
const P = require('pino')
const path = require('path')
const TBotZapData = require('./Util/TBotZapData')

var msgRetryCounterMap = {};

async function TBotZap(){
   
        const { state, saveCreds } = await useMultiFileAuthState('/etc/TerminusBot/TBotZap/auth_info_baileys')
        const conn = makeWASocket({
            logger: P({ level: 'silent' }),
                printQRInTerminal: true,
                auth: state,
                msgRetryCounterMap: MessageRetryMap,
                defaultQueryTimeoutMs: undefined, 
                keepAliveIntervalMs: 1000 * 60 * 10 * 3

        })
    
        conn.ev.on('connection.update', (update) => {
            const { connection, lastDisconnect } = update
            if(connection === 'close') {
                const shouldReconnect = lastDisconnect.output !== DisconnectReason.loggedOut
                console.log('connection closed due to '+ lastDisconnect.output)
                // reconnect if not logged out
                if(shouldReconnect) {
                    TBotZap()
                }
            } else if(connection === 'open') {
                console.log('opened connection')
                TBotZapNLP.train()
                
            }

        })
 
        conn.ev.on("creds.update", saveCreds);
        conn.ev.on('messages.upsert', async (message) => {
            console.log(JSON.stringify(message, undefined, 2));
            let jid = message.messages[0].key.remoteJid
            if(message && !jid.endsWith("@g.us") && message.messages[0].message){
                    
               
                const reply =  message.messages[0]
                var msg = message.messages[0].message.conversation
                const key = message.messages[0].key 
                const user= message.messages[0].pushName
                let isGroup = false
                jid.endsWith("@g.us") ? isGroup = true : isGroup = false
                  
                    console.log(JSON.stringify(message.messages[0].key))
                if(msg){
                    TBotZapNLP.answer(msg.toLowerCase())
                    .then( async (answer) => {
                        switch(answer.intent){
                            case "SAUDACAO.RECEPCAO":
                                const welcomeMessage = {
                                    text: `
Olá, Bem vindo! Como posso te ajudar?

==============================
📡 𝙄𝙉𝙏𝙀𝙍𝙉𝙀𝙏 𝙈𝙊́𝙑𝙀𝙇 𝙄𝙇𝙄𝙈𝙄𝙏𝘼𝘿𝘼 📡
==============================

🌐𝙊𝙋𝙀𝙍𝘼𝘿𝙊𝙍𝘼𝙎 𝘿𝙄𝙎𝙋𝙊𝙉𝙄́𝙑𝙀𝙄𝙎🌐

   🟣ᴠɪᴠᴏ
   🔵ᴛɪᴍ
   🔴ᴄʟᴀʀᴏ 
   🟡ᴏɪ 
   
==============================
         ⏳𝙏𝙀𝙎𝙏𝙀  1 𝙃𝙊𝙍𝘼 𝙂𝙍𝘼́𝙏𝙄𝙎⏳
==============================

🔴𝙔𝙊𝙐𝙏𝙐𝘽𝙀 1080𝙋
📺𝙄𝙋𝙏𝙑 𝙁𝙐𝙇𝙇 𝙃𝘿
🎥 𝙉𝙀𝙏𝙁𝙇𝙄𝙓
🎮𝙅𝙊𝙂𝙊𝙎

𝘼𝘾𝙀𝙎𝙎𝙊 𝘿𝙀  ${TWABotFirstLoginTime()} 𝘿𝙄𝘼𝙎 𝙍$ ${TWABotFirsLoginPrice()}

𝙁𝙊𝙍𝙈𝘼𝙎 𝘿𝙀 𝙋𝘼𝙂𝘼𝙈𝙀𝙉𝙏𝙊:

💠𝘼𝙋𝙀𝙉𝘼𝙎 𝙑𝙄𝘼 𝙋𝙄𝙓💠

𝕋𝔼𝕄𝕆𝕊 ℙ𝔸𝕀ℕ𝔼𝕃 ℙℝ𝔸 ℝ𝔼𝕍𝔼ℕ𝔻𝔼𝔻𝔸
 
10 𝙇𝙊𝙂𝙄𝙉𝙎    𝙍$ 30,00   30 𝘿𝙄𝘼𝙎
20 𝙇𝙊𝙂𝙄𝙉𝙎    𝙍$ 40,00   30 𝘿𝙄𝘼𝙎
30 𝙇𝙊𝙂𝙄𝙉𝙎    𝙍$ 60,00   30 𝘿𝙄𝘼𝙎

╔─━━━░    ★     ░━━━─╗
🇧🇷                                             🇧🇷
     𝒞𝒪𝑀𝒫𝑅𝐸 𝒮𝐸𝒰 𝒜𝒞𝐸𝒮𝒮𝒪
🇧🇷                                             🇧🇷
╚─━━━░     ★    ░━━━─╝

⚡️ Após Pagamento Seu usuário e senha será entregue junto com aplicativo ✅`,
                                    footer: 'walisonSCH',
                                    buttons:  [
                                        {buttonId: 'continuar', buttonText: {displayText: 'Continuar'}, type: 1},
                                        {buttonId: 'sair', buttonText: {displayText: 'Sair'}, type: 1},
                                      ],
                                    headerType: 1
                                }
                            
                                delay(500)
                    
                                await conn.readMessages([key])
                                await delay(500)
                                        await conn.sendMessage(jid, welcomeMessage)

                              
                            break
                            case "INTENCAO.CONTAS":
                                await conn.readMessages([key])
                                delay(500)
                                let userId
                                isGroup ? userId = message.messages[0].key.participant : userId = jid
                                if(TWABotFileExist({path: '/etc/TerminusBot/TBotZap/usuarios/account_recovery.json'})){
                        
                                    fs.readFile('/etc/TerminusBot/TBotZap/usuarios/account_recovery.json', {encoding: 'utf-8'}, async (error, data) => {
                                      if(error == null){
                                        const pedido_json = JSON.parse(data)
                                        if(pedido_json.length > 0){
                                          const userExist = pedido_json.find(findEl => findEl.chat_id == userId)
                                          if(userExist != undefined){
                                            var account_list = ''
                                            for(var i in pedido_json){
                                                if(pedido_json[i].chat_id.includes(userId)){
                                                    await conn.sendPresenceUpdate('composing', userId)
                                                    await delay(100)
                                                    await conn.sendMessage(userId, {text:  `
*CONTA CRIADA COM SUCESSO!*
*Usuário:* ${pedido_json[i].ssh_account}
*Senha:* ${pedido_json[i].ssh_password}
*Expira:* ${pedido_json[i].ssh_expire}
*Limite:* ${pedido_json[i].ssh_limit}
*Pedido:* ${pedido_json[i].order_id}
▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔
Link de download
APLICATIVO: ${TWABotLinkMediafire()}
▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔
Grupo de suporte
GRUPO: ${TWABotLinkPlayStore()}
▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔
Obrigado por adquirir nosso produto.`
                                                    })
                                              
                                                }
                                            }
                                          }else{
                                            await conn.sendPresenceUpdate('composing', jid)
                                            await delay(100)
                                            await conn.sendMessage(jid, {text: '*Ainda não confirmamos o seu pagamento. Tente mais tarde.*'})
                                          }
                                
                                           
                                        }else {
                                        
                                            await conn.sendPresenceUpdate('composing', jid)
                                            await delay(100)
                                            await conn.sendMessage(jid, {text: '*Ainda não confirmamos o seu pagamento. Tente mais tarde.*'})
                                        }
                                      }
                                      
                                    })
                                   
                                }else{
                                    await conn.readMessages([key])
                                    await delay(500)
                                    await conn.sendPresenceUpdate('composing', jid)
                                    await delay(100)
                                    await conn.sendMessage(jid, {text: '*Ainda não confirmamos o seu pagamento. Tente mais tarde.*'})
                                }
                            break

                        }



                        
                    })
                }

                if(message.messages[0].message.buttonsResponseMessage != null ){

                    if(message.messages[0].message.buttonsResponseMessage.selectedButtonId == "continuar"){
                        const buttons = [
                            {buttonId: 'comprar_acesso', buttonText: {displayText: '🛒 COMPRAR VPN 🛒'}, type: 1},
                            {buttonId: 'teste_gratis', buttonText: {displayText: '♻️GERAR TESTE♻️'}, type: 1},
                            {buttonId: 'verificar_pagamento', buttonText: {displayText: '♻️VERIFICAR PAGAMENTO♻️'}, type: 1},
                        ]
                    
                        const buttonListMessage = {
                            text: "*"+user+"* veja as opções",
                            footer: 'walisonSCH ',
                            buttons: buttons,
                            headerType: 1
                        }

                        await conn.readMessages([key])
                        await delay(500)
                        await conn.sendPresenceUpdate('composing', jid)
                        await delay(500)
                        await conn.sendMessage(jid, buttonListMessage)
                    }
 
                    if(message.messages[0].message.buttonsResponseMessage.selectedButtonId == "comprar_acesso"){
                        const buttons = [
                            {buttonId: 'comprar', buttonText: {displayText: 'Comprar'}, type: 1},
                            {buttonId: 'cancelar', buttonText: {displayText: 'Cancelar'}, type: 1},
                          ]
                    
                        const buttonAccounOne ={ 
                    text: `
📌  DETALHES DA COMPRA 📌

👜 *PRODUTO:* ACESSO VPN

💰 *PREÇO:* ${TWABotFirsLoginPrice()} Reais

📅 *VALIDADE:* ${TWABotFirstLoginTime()} Dias

👤 *USUÁRIOS:* ${TWABotLoginLimit()} Usuário`,
                    footer: 'walisonSCH',
                    buttons: buttons,
                    headerType: 1
                    
                        }
                    

                        await conn.readMessages([key])
                        await conn.sendPresenceUpdate('composing', jid)
                        await delay(500)
                        await conn.sendMessage(jid, buttonAccounOne)
                    }



                    if(message.messages[0].message.buttonsResponseMessage.selectedButtonId == "teste_gratis"){
                        
                        await conn.readMessages([key])
                        await conn.sendPresenceUpdate('composing', jid)
                        await delay(500)
                        await conn.sendMessage(jid, {text: "*Só um momento estou gerando o seu teste gratis*"})

                        TBotZapFreeAccount(isGroup ? message.messages[0].key.participant : jid)
                        .then(async (response) => {
                            if(response.status){

                                const buttons = [
                                    {buttonId: 'btn_mediafire', buttonText: {displayText: '📲APLICATIVO📲'}, type: 1},
                                  ]
                            
                                const buttonAccounOne ={ 
                            text: response.payload,
                            footer: 'Para baixar nosso app escolha um dos botões acima.',
                            buttons: buttons,
                            headerType: 1
                            
                                }

                                await delay(500)
                                await conn.sendPresenceUpdate('composing', isGroup ? message.messages[0].key.participant : jid)
                                await delay(500)
                                await conn.sendMessage(isGroup ? message.messages[0].key.participant : jid, buttonAccounOne)
                            }else{
                                await delay(500)
                                await conn.sendPresenceUpdate('composing', jid)
                                await delay(500)
                                await conn.sendMessage(jid, {text:"😟 *Sinto muito, mas você já esgotou seu limite de teste grátis. Mas não fique sem internet, aproveite nosso desconto.*"}, {quoted: reply})
                            
                            }
                        })
                    }

                    if(message.messages[0].message.buttonsResponseMessage.selectedButtonId == "suporte_cliente"){
                   
                        await conn.readMessages([key])
                        delay(500)
                        const link_support = "Envie uma mensagem pelo link: "+TWABotLinkSupport()
                        await delay(500)
                        await conn.sendMessage(jid, {text: link_support})

                       
                    }

                    if(message.messages[0].message.buttonsResponseMessage.selectedButtonId == "verificar_pagamento"){
                        await conn.readMessages([key])
                        await delay(500)

                        if(TWABotFileExist({path: '/etc/TerminusBot/TBotZap/usuarios/account_recovery.json'})){
                        
                            fs.readFile('/etc/TerminusBot/TBotZap/usuarios/account_recovery.json', {encoding: 'utf-8'}, async (error, data) => {
                              if(error == null){
                                const pedido_json = JSON.parse(data)
                                if(pedido_json.length > 0){
                                  const userExist = pedido_json.find(findEl => findEl.chat_id == jid)
                                  if(userExist != undefined){
                                    var account_list = ''
                                    for(var i in pedido_json){
                                        if(pedido_json[i].chat_id.includes(jid)){
                                            await conn.sendPresenceUpdate('composing', jid)
                                            await delay(100)
                                            await conn.sendMessage(jid, {text:  `
*CONTA CRIADA COM SUCESSO!*
*Usuário:* ${pedido_json[i].ssh_account}
*Senha:* ${pedido_json[i].ssh_password}
*Expira:* ${pedido_json[i].ssh_expire}
*Limite:* ${pedido_json[i].ssh_limit}
*Pedido:* ${pedido_json[i].order_id}
▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔
Link de download
APLICATIVO: ${TWABotLinkMediafire()}
▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔
Grupo de suporte
GRUPO: ${TWABotLinkPlayStore()}
▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔
Obrigado por adquirir nosso produto.`
                                            })
                                      
                                        }
                                    }
                                  }else{
                                    await conn.sendPresenceUpdate('composing', jid)
                                    await delay(100)
                                    await conn.sendMessage(jid, {text: '*Ainda não confirmamos o seu pagamento. Tente mais tarde.*'})
                                  }
                        
                                   
                                }else {
                                
                                    await conn.sendPresenceUpdate('composing', jid)
                                    await delay(100)
                                    await conn.sendMessage(jid, {text: '*Ainda não confirmamos o seu pagamento. Tente mais tarde.*'})
                                }
                              }
                              
                            })
                           
                        }else{
                            await conn.readMessages([key])
                            await delay(500)
                            await conn.sendPresenceUpdate('composing', jid)
                            await delay(100)
                            await conn.sendMessage(jid, {text: '*Ainda não confirmamos o seu pagamento. Tente mais tarde.*'})
                        }

                    }


                    if(message.messages[0].message.buttonsResponseMessage.selectedButtonId == "btn_playstore"){
                   
                        await conn.readMessages([key])
                        delay(500)
                        await delay(100)
                        await conn.sendPresenceUpdate('composing', jid)
                        const link_playstore = "Acesse grupo suporte por este link: "+TWABotLinkPlayStore()
                        await delay(500)
                        await conn.sendMessage(jid, {text:link_playstore})
                       
                    }
    
                    if(message.messages[0].message.buttonsResponseMessage.selectedButtonId == "btn_mediafire"){
                       
                        await conn.readMessages([key])
                        delay(500)
                        const link_mediafire = "Baixe nosso aplicativo  por este link: "+TWABotLinkMediafire()
                        await delay(500)
                        await conn.sendMessage(jid, {text: link_mediafire})
                       
                    }
        
                    if(message.messages[0].message.buttonsResponseMessage.selectedButtonId == "comprar"){
                        
                        QRcode.generate({chatId: isGroup ? message.messages[0].key.participant : jid})
                        .then(async (payload) => {
                            console.log(payload)
                            await delay(100)
                            await conn.sendPresenceUpdate('composing', payload.chat)
                            await delay(100)
                            await conn.sendMessage(jid, {text: "*Só um momento estou gerando o QRCode.*"})
                            await delay(500)
                            if(payload.status){
                                await delay(500)
                                await conn.sendPresenceUpdate('composing', payload.chat)
                                await delay(200)
                                await conn.sendMessage(jid, {text: `${payload.qrCode}`})
                            }
                            await delay(100)
                            await conn.sendPresenceUpdate('composing', payload.chat)
                            await conn.sendMessage(jid, {text: `Guarde o seu úmero do pedido: ${payload.orderId}`})
                            await conn.sendPresenceUpdate('composing', jid)
                            await delay(100)
                            await conn.sendMessage(jid, {text: "O QRCode foi gerado. Assim que confirmarmos o pagamento, você receberá o seu login. *Ou se preferir digite:* _Não recebi a minha conta_"})
                           
                        })
                    
                    }
                }


            }
        })
 

}
     

TBotZap()
